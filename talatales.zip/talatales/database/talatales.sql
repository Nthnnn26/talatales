-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2024 at 01:36 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `talatales`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_story`
--

CREATE TABLE `tbl_story` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `favorite` int(255) NOT NULL COMMENT '0=no 1=yes',
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `about` varchar(999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_story`
--

INSERT INTO `tbl_story` (`id`, `user_id`, `category`, `favorite`, `title`, `author`, `image`, `about`) VALUES
(995, 999, 'fable', 0, 'The Tortoise and the Hare', 'Jeanelle S. Yee', 'thetortoise.png', 'In the classic tale of \"The Hare and the Tortoise,\" a boastful hare challenges a slow-moving tortoise to a race. The hare, confident in his speed, takes an early lead, while the tortoise plods along steadily. Who do you think will win the race: the speedy hare or the steady tortoise?'),
(996, 999, 'fairy-tale', 0, 'Story time stars', 'Jeanelle S. Yee', 'thetortoise.png', 'PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER\r\nPLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER'),
(997, 999, 'adventure', 0, 'The Turle', 'Jeanelle S. Yee', 'thetortoise.png', 'PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER\r\nPLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER\r\nPLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER'),
(998, 999, 'fantasy', 0, 'The cat and Snarl', 'Jeanelle S. Yee', 'thetortoise.png', 'PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER\r\nPLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER\r\nPLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(255) NOT NULL,
  `EmailAddress` varchar(255) NOT NULL,
  `PassWord` varchar(255) NOT NULL,
  `Avatar` varchar(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `code` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `EmailAddress`, `PassWord`, `Avatar`, `Name`, `code`) VALUES
(999, 'nathan.ivanmendoza@gmail.com', '123', 'img/Bird.svg', 'Nathan', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_story`
--
ALTER TABLE `tbl_story`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_story`
--
ALTER TABLE `tbl_story`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=999;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1001;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
