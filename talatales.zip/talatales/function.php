<?php
include'config.php';
$action = $_GET['action'];
$email = $_SESSION['email'];

if ($action == 'save_avatar') {
    $imagePath = $_POST['imagePath'];

    $sql = "UPDATE tbl_user SET Avatar = '$imagePath' WHERE EmailAddress = '$email'";

    if (mysqli_query($dbcon, $sql)) {
        echo 'Image path inserted successfully';
    } else {
        echo 'Error: ' . mysqli_error($dbcon);
    }
}

if ($action == 'update_fav') {
    $storyId = $_POST['story_id'];
    $favoriteStatus = $_POST['favorite'];

    $query = "UPDATE tbl_story SET favorite = $favoriteStatus WHERE id = $storyId";
    echo "Success";
}

if ($action =='start_story') {
    $_SESSION['story_started'] = true;
}
?>
