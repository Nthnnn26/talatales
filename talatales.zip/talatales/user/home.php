<?php 
include'../config.php';


if (empty($_SESSION['new_user'])) {
    $isFromSetupPage = false;
} else {
    $isFromSetupPage = true;
}
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>TalaTales</title>
        <!---CSS LINK--->
        <link rel="stylesheet" href="../style.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
        <style>   
        .btn-round {
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            border-bottom-left-radius: 0px;
            border-bottom-right-radius: 0px;
            display: inline-block;
            color: #6C628D; 
            min-width: 150px;
            min-height: 40px;
            border: none;
            border-right: 2px solid #808080;
            background-color: white;
        }       
        .active-btn {
            background-color: #DEE0F3;      
        }
        .scrollable {
            overflow-x: auto;
            white-space: nowrap;
            -webkit-overflow-scrolling: touch;
        }
        .scrollable::-webkit-scrollbar {
            display: none;
        }
        .scrollable {
            scrollbar-width: none;
        }
        .story {
            display: none;
        }
        .tour-container {
            position: fixed;
            top: 30%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .tour-box {
            width: 300px;
            height: auto;
            background-color: #DEE0F3;
            border-radius: 15px; /* Adjust the radius to your liking */
            padding: 20px;
            color: #6C628D;
            text-align: center;
        }

        #next-btn {       
            color: white;    
            border-radius: 5px;
            background-color: #6C628D;
            border: none;
            margin-top: 10px;
            cursor: pointer;
        }
        p {
            font-size: medium;
        }     
        .bg-image {   
            background: url('../img/Search.png');
            background-blend-mode: multiply;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            width: 100%;
            height: 350px;
        }
        .custom-logo {
            width: 150px;
            margin-top: -10px;
        }
        
        .logout-icon {
            display: none;
        }
        footer {
            background-image: url('../img/footer.png'); 
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;    
            height: 450px; 
            display: flex;   
            justify-content: center;
            align-items: center;
            position: relative;
        }
        .about-content{
            flex-direction: row;
        }
        .logo-container {
            position: absolute;
            top: 0;
            margin-top: 40px;
        }
        .favorite {
            background-image: url('../img/favorite.png'); 
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            position: absolute; 
            width: 70px; 
            height: 90px; 
            top: 0; 
            right: 0; 
            margin-right: 30px; 
            cursor: pointer;
        }
         @media (max-width: 576px) {
            .logout-icon {
                display: inline-block;
            }
            p {
                font-size: small;
            }  
            .sidebar {
                background-color: rgb(255, 255, 255, 0.15);
                backdrop-filter: blur(16px);    
            }
            .custom-logo {
                margin-top: 0px;
            }
            .about-content {
                flex-direction: column; 
                text-align: center;              
            }
            .bg-image {   
                height: 250px;
            }
            footer {
                height: 450px;
                background-image: url('../img/mobile-footer.png');
            }
            .favorite {
            width: 50px; 
            height: 70px;           
            }
        }
        </style>
    </head>

    <body>           
        <header>
            <nav class="navbar navbar-expand-lg bg-transparent">
                <div class="container-fluid">
                    <img class="img-fluid custom-logo" src="../img/Logo(Multicolor).svg" alt="SVG Image">
                    <button class="navbar-toggler shadow-none border-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="sidebar offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                            <div class="offcanvas-header text-lighblue border-bottom">
                                <img id="offcanvasNavbarLabel" class="img-fluid" style="width: 150px" src="../img/Logo(Multicolor).svg" alt="SVG Image">
                                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                            </div>                         
                        <div class="offcanvas-body">
                            <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                                <li class="nav-item" style="margin-right: 10px;">
                                    <a class="nav-link" href="home.php"><h5><img src="../img/Home(Fill).svg" alt="SVG Image" style="max-height: 30px;">  Home</h5></a>
                                </li>
                                <li class="nav-item" style="margin-right: 10px;">
                                    <a class="nav-link" href="library.php"><h5><img src="../img/My Library (Outline).svg" alt="SVG Image" style="max-height: 30px;">  My Library</h5></a>
                                </li>
                                <li class="nav-item" style="margin-right: 10px;">
                                    <a class="nav-link" href="profile.php"><h5><img src="../img/Profile(Outline).svg" alt="SVG Image" style="max-height: 30px;">  Profile</h5></a>
                                </li>                        
                            </ul>
                                <div class="ms-auto mt-2">
                                    <a class="nav-link" href="../logout.php"><h4><img src="../img/LogoutExit.svg" alt="SVG Image" class="mb-2 logout-icon" style="max-height: 25px;">   Log out</h4></a>
                                </div>
                                <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
                                <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
                                <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
                            </div>                      
                        </div>
                    </div>
                </nav>   
        </header>  

        <div class="container-fluid d-flex flex-column justify-content-center align-items-center" style="width: 100%; padding: 0;">
            <div class="row bg-image">               
                <div class="row align-items-center justify-content-center mt-auto" style="margin-left: auto; margin-right: auto;">
                    <form style="max-width: 450px;">
                        <div class="input-group mb-3">
                            <input class="form-control form-control-lg" style="border: none; border-top-left-radius: 25px; border-bottom-left-radius: 25px; padding-top: 5px;" type="search" placeholder="Search a story">
                            <button class="btn btn-effect btn-md" type="submit" style="background-color: white; border-top-right-radius: 25px; border-bottom-right-radius: 25px;">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                    </form>
                </div>           
            </div>
        </div>
        
        <div class="row" style="height: 100%; width: 100%;">
            <section class="categories">
                <div class="row mt-4">
                    <div class="scrollable">
                        <button class="btn-lg btn-round active-btn" onclick="changeCategory('fable')">Fable</button>
                        <button class="btn-lg btn-round" onclick="changeCategory('fairy-tale')">Fairy Tale</button>
                        <button class="btn-lg btn-round" onclick="changeCategory('fantasy')">Fantasy</button>
                        <button class="btn-lg btn-round" onclick="changeCategory('adventure')">Adventure</button>
                    </div>
                </div> 
            </section>
        </div>

        <div class="d-flex" style="background-color: #DEE0F3;">   
        <?php
            if (isset($_SESSION['user_id'])) {
            
            $query = mysqli_query($dbcon, "SELECT tbl_story.id AS story_id, tbl_user.id AS user_id, tbl_story.*, tbl_user.* FROM tbl_story JOIN tbl_user ON tbl_story.user_id = tbl_user.id") or die(mysqli_error(die));
            while($row =  mysqli_fetch_array($query, MYSQLI_ASSOC)):
        ?>            
            <!--story-->
            <div class="box category <?php echo $row['category'] ?>" style="padding: 20px; <?php echo ($row['category'] != 'fable') ? 'display: none;' : ''; ?>" data-toggle="modal" data-target="#modal<?php echo $row['story_id'] ?>">
                <div style="cursor: pointer;">
                    <img src="../assets/<?php echo $row['image'] ?>" alt="Png Image" style="width: 130px; height: 173px; border: 5px solid #FFF; box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.5);">
                </div>
                <h6 style="max-width: 140px;"><?php echo $row['title'] ?></h6>
            </div>

            <div class="modal fade" id="modal<?php echo $row['story_id'] ?>" tabindex="-1" role="dialog" aria-labelledby="customModalLabel" aria-hidden="true" data-backdrop="true" data-keyboard="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content text-center align-items-center" style="border-radius: 40px; background-color: #DEE0F3; position: relative;">                         
                        <div class="container-fluid d-flex justify-content-center align-items-center favorite" onclick="changeImage('<?php echo $row['story_id'] ?>')">
                            <img id="<?php echo $row['story_id'] ?>" class="img-fluid" src="<?php echo ($row['favorite'] == 1) ? '../img/heart-fill.png' : '../img/heart.png'; ?>" alt="png">
                        </div>                             
                                         
                        <div style="padding-top: 20px;">
                            <img src="../assets/<?php echo $row['image'] ?>" alt="Png Image" style="width: 110px; height: 150px; border: 5px solid #FFF; box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.5);">
                        </div>    

                            <p class="lead font-weight-bold" style="margin: 0; color: #1A3057;"><?php echo $row['title'] ?></p>
                            <p style="margin: 0; color: #6C628D;">Aesop</p> 
                            <p style="margin: 0; color: #6C628D;">Illustrated by;</p>  
                            <p style="margin: 0; color: #6C628D;"><?php echo $row['author'] ?></p>
                            <p style="margin: 20px; color: #6C628D;"><?php echo $row['about'] ?></p>                             
                        
                        <div class="modal-footer w-100" style="border: none;">                              
                            <div class="d-flex w-100 justify-content-around">
                                <button type="button" class="btn-block btn-md img-fluid" style="background: transparent; border: none;"><img class="img-fluid" src="../img/read.png" alt="png image"></button>
                                <button type="button" class="btn-block btn-md" style="background: transparent; border: none;" disabled><img src="../img/play_lock.png" alt="png image"></button>
                            </div>                                             
                        </div>                     
                    </div>
                </div>
            </div>
        <?php               
            endwhile;
        }
        else {
            $query = mysqli_query($dbcon, "SELECT * FROM tbl_story WHERE user_id = 999") or die(mysqli_error(die));
            while($row =  mysqli_fetch_array($query, MYSQLI_ASSOC)):
        ?>
        
            <!--story-->
            <div class="box category <?php echo $row['category'] ?>" style="padding: 20px; <?php echo ($row['category'] != 'fable') ? 'display: none;' : ''; ?>" data-toggle="modal" data-target="#modal<?php echo $row['id'] ?>">
                <div style="cursor: pointer;">
                    <img src="../assets/<?php echo $row['image'] ?>" alt="Png Image" style="width: 130px; height: 173px; border: 5px solid #FFF; box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.5);">
                </div>
                <h6 style="max-width: 140px;"><?php echo $row['title'] ?></h6>
            </div>


            <div class="modal fade" id="modal<?php echo $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="customModalLabel" aria-hidden="true" data-backdrop="true" data-keyboard="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content text-center align-items-center" style="border-radius: 40px; background-color: #DEE0F3; position: relative;">                         
                        <div class="container-fluid d-flex justify-content-center align-items-center favorite" onclick="changeImage('<?php echo $row['id'] ?>')">
                            <img id="<?php echo $row['id'] ?>" class="img-fluid" src="<?php echo ($row['favorite'] == 1) ? '../img/heart-fill.png' : '../img/heart.png'; ?>" alt="png">
                        </div>                             
                                         
                        <div style="padding-top: 20px;">
                            <img src="../assets/<?php echo $row['image'] ?>" alt="Png Image" style="width: 110px; height: 150px; border: 5px solid #FFF; box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.5);">
                        </div>    

                            <p class="lead font-weight-bold" style="margin: 0; color: #1A3057;"><?php echo $row['title'] ?></p>
                            <p style="margin: 0; color: #6C628D;">Aesop</p> 
                            <p style="margin: 0; color: #6C628D;">Illustrated by;</p>  
                            <p style="margin: 0; color: #6C628D;"><?php echo $row['author'] ?></p>
                            <p style="margin: 20px; color: #6C628D;"><?php echo $row['about'] ?></p>                             
                        
                        <div class="modal-footer w-100" style="border: none;">                              
                            <div class="d-flex w-100 justify-content-around">
                                <button type="button" class="btn-block btn-md img-fluid" style="background: transparent; border: none;"><img class="img-fluid" src="../img/read.png" alt="png image"></button>
                                <button type="button" class="btn-block btn-md" style="background: transparent; border: none;" disabled><img src="../img/play_lock.png" alt="png image"></button>
                            </div>                                             
                        </div>                     
                    </div>
                </div>
            </div>
        <?php               
            endwhile; } ?>
        </div>  
               
        <div class="container d-flex justify-content-center align-items-center">
            <div class="row min-vh-100 justify-content-center">
                <div class="col-md-6 d-flex justify-content-center align-items-center flex-column left-box">
                    <h1 style="color: #1A3057;">Hi! My name is <spa style="color: #FCC710;">Tala</spa>....</h1>
                </div>
                <div class="col-md-6 d-flex justify-content-center align-items-center flex-column right-bo">
                <div class="row">
                        <img class="img-fluid" src="../img/Tala.svg" alt="SVG Image">
                    </div>
                </div>
            </div>
        </div>
        
        <div class="container d-flex justify-content-center align-items-center">
            <div class="row min-vh-100 justify-content-center">
                <div class="d-flex justify-content-center align-items-center flex-column" style="max-width: 600px;">
                    <div class="row align-items-center">
                        <strong><h2 style="color: #6C628D;">About Us</h2></strong>
                    </div>
                    <div class="row align-items-center">
                        <p class="text-center" class="text-center" style="color: #6C628D;">PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER</p>
                    </div>
                </div>

                <div class="d-flex justify-content-center align-items-center justify-content-between about-content">
                    <div class="row justify-content-center align-items-center" style="max-width: 350px;">
                        <h3 class="text-center" style="color: #6C628D;">About Us</h3>
                    <div class="row align-items-center">
                        <p class="text-center" style="color: #6C628D;">PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER</p>
                    </div>
                    </div>
                    <div class="row justify-content-center align-items-center" style="max-width: 350px;">
                        <h3 class="text-center" style="color: #6C628D;">About Us</h3>
                    <div class="row align-items-center">
                        <p class="text-center" style="color: #6C628D;">PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER</p>
                    </div>
                    </div>
                    <div class="row justify-content-center align-items-center" style="max-width: 350px;">
                        <h3 class="text-center" style="color: #6C628D;">About Us</h3>
                    <div class="row align-items-center">
                        <p class="text-center" style="color: #6C628D;">PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER PLACEHOLDER</p>
                    </div>
                    </div>
                </div>
            </div>
        </div>
         
        <footer>  
            <div class="logo-container">
                <div class="container-fluid">
                    <img class="img-fluid custom-logo" src="../img/Logo(Multicolor).svg" alt="SVG Image">
                </div>
            </div>       
                <div class="container d-flex justify-content-center align-items-center about-content">
                    <div class="row p-3">
                        <a href="#"><h3>Home</h3></a>
                    </div>
                    <div class="row p-3">
                        <a href="#"><h3>Terms & Conditions</h3></a>
                    </div>
                    <div class="row p-3">
                        <a href="#"><h3>About Us</h3></a>
                    </div>
                </div>      
        </footer>
    
    <?php
        // Show the tour container only if the user is coming from setup.php
        if ($isFromSetupPage) {  
            unset($_SESSION['new_user']);            
        ?>
            <div class="tour-container">
                <div class="tour-box">
                    <p id="tour-text">Welcome to our website! Click "Next" to learn how to navigate.</p>
                    <button id="next-btn" onclick="nextStep()">Next</button>
                </div>
            </div>
        <?php
        }
    ?>

    <script src="../script.js"></script>
    <script>
        function changeImage(imageId) {
        var heartImage = document.getElementById(imageId);

        // Check the current source and change it accordingly
        if (heartImage.src.includes('heart.png')) {
            heartImage.src = '../img/heart-fill.png'; // Change this to the new image path
        } else {
            heartImage.src = '../img/heart.png'; // Change this back to the original image path or another image path
        }
    }

        function changeCategory(category) {
       // Hide all stories
        document.querySelectorAll('.box').forEach(function(box) {
            box.style.display = 'none';
        });

        // Show stories of the selected category
        document.querySelectorAll('.box.' + category).forEach(function(box) {
            box.style.display = 'block';
        });

        // Update active button
        const buttons = document.querySelectorAll('.btn-round');
        buttons.forEach(button => button.classList.remove('active-btn'));
        event.currentTarget.classList.add('active-btn');
    }
    
    

    
    </script>
    </body>
</html>