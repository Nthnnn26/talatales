<?php 
$email = $_SESSION['email'];
echo $email;
?>