<?php 
include'../config.php';

?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>TalaTales</title>
        <!---CSS LINK--->
        <link rel="stylesheet" href="../style.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
        <style>
            .custom-logo {
                width: 150px;
                margin-top: -10px;
            }
            .rounded-container-left {
                height: 60vh;
                background-color: #DEE0F3;
                border-radius: 20px; /* Set the border-radius for rounded corners */
                display: flex;
                justify-content: center;
                align-items: center;
            }
            .rounded-container-right {
                background-color:#DEE0F3;
                border-radius: 20px; /* Set the border-radius for rounded corners */
                height: 60vh;
                display: flex;              
                align-items: center;
            }
            .logout-icon {
                display: none;
            }
            @media (max-width: 576px) {
                .logout-icon {
                    display: inline-block;
                }
                .custom-logo {
                    margin-top: 0px;
                }
                .sidebar {
                    background-color: rgb(255, 255, 255, 0.15);
                    backdrop-filter: blur(16px);    
                }
                .fixed-bottom-div {
                    height: 85%;
                }
                .rounded-container-left {
                    height: 40vh;
                }
                
                .rounded-container-right {
                    height: 40vh;
                    margin-top: 20px;
                   
                }
                .custom {               
    
                    width: 180px;
                    height: 180px;
                }
            }
        </style>
    </head>

    
    <body> 
        <header>
            <nav class="navbar navbar-expand-lg bg-transparent">
                <div class="container-fluid">
                    <img class="img-fluid custom-logo" src="../img/Logo(Multicolor).svg" alt="SVG Image">
                    <button class="navbar-toggler shadow-none border-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="sidebar offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                            <div class="offcanvas-header text-lighblue border-bottom">
                                <img id="offcanvasNavbarLabel" class="img-fluid" style="width: 150px" src="../img/Logo(Multicolor).svg" alt="SVG Image">
                                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                            </div>
                        <div class="offcanvas-body">
                            <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                                <li class="nav-item" style="margin-right: 10px;">
                                    <a class="nav-link" href="home.php"><h5><img src="../img/Home(Outline).svg" alt="SVG Image" class="mb-2" style="max-height: 30px;">  Home</h5></a>
                                </li>
                                <li class="nav-item" style="margin-right: 10px;">
                                    <a class="nav-link" href="library.php"><h5><img src="../img/My Library (Outline).svg" alt="SVG Image"  class="mb-2" style="max-height: 30px;">  My Library</h5></a>
                                </li>
                                <li class="nav-item" style="margin-right: 10px;">
                                    <a class="nav-link" href="profile.php"><h5><img src="../img/Profile(Fill).svg" alt="SVG Image" class="mb-2" style="max-height: 30px;">  Profile</h5></a>
                                </li>                          
                            </ul>
                                <div class="ms-auto mt-2">
                                    <a class="nav-link" href="../logout.php"><h4><img src="../img/LogoutExit.svg" alt="SVG Image" class="mb-2 logout-icon" style="max-height: 25px;">   Log out</h4></a>
                                </div>
                                <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
                                <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
                                <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
                            </div>                      
                        </div>
                    </div>
                </nav>   
        </header>   
        
        <div class="container-fluid mt-5">
            <div class="row align-items-center">
                <div class="col-md-4 d-flex justify-content-center align-items-center flex-column left-box">                   
                    <div class="container flex-column align-items-center rounded-container-left">
                        <div class="row text-center">
                            <h1 style="color: #6C628D;">Hello!</h1>
                        </div>
                        <?php if(isset($_SESSION['user_id'])): ?>
                        <div class="row justify-content-center align-items-center custom">
                            <img src="../<?php echo $_SESSION['avatar']; ?>" class="img-fluid" alt="SVG Image"> 
                        </div>
                        <div class="row text-center">
                            <h1 style="color: #6C628D;"><?php echo $_SESSION['name']; ?></h1>
                        </div> 
                        <?php endif; ?> 
                    </div>          
                </div>
                <div class="col-md-8 d-flex justify-content-center align-items-center flex-column right-box">
                    <div class="container flex-column align-items-center rounded-container-right"> 
                        <div class="row text-center mt-3">
                            <h4 style="color: #6C628D;">Badges</h4>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>